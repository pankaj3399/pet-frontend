
export const ROUTES = {
    Home:'/',
    PetPage:'/pets',
    Contact:'/contact',
    Login: '/login',
    Register: '/register',
    Admin: '/admin',
}